// Include necessary standard and driver-specific header files
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

/* Include Texas Instruments drivers */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART2.h>
#include <ti/drivers/Timer.h>

/* Include device-specific configuration */
#include "ti_drivers_config.h"

// Task schedule time intervals in milliseconds
#define UPDATE_BUTTON_MS    200
#define UPDATE_TEMP_MS      500
#define UPDATE_UART_MS      1000

// Macro to simplify UART display usage
#define DISPLAY(x) UART2_write (uart, &output, x, NULL);

// UART communication global variables
char output[64];
UART2_Handle uart;

// I2C communication global variables for sensor interaction
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;
I2C_Handle i2c;

// Timer variables for scheduling
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;

// Temperature control variables
volatile int16_t temperature = 20;
volatile int16_t setpoint = 22;
volatile uint32_t seconds = 0;
volatile int heat = 0;

// Initialize UART for communication
void initUART(void)
{
    UART2_Params uartParams;
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;
    uartParams.readMode = UART2_Mode_BLOCKING;
    uartParams.writeMode = UART2_Mode_BLOCKING;
    uart = UART2_open(CONFIG_UART2_0, &uartParams);
    if (uart == NULL) {
        while (1); // Enter an infinite loop if UART fails
    }
}

// Initialize I2C for sensor communication
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;
    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "));
    I2C_init();
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, 64, "Failed\n\r"));
        while (1); // Enter an infinite loop if I2C fails
    }
    DISPLAY(snprintf(output, 32, "Passed\n\r"));
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    found = false;
    for (i = 0; i < 3; ++i)
    {
        i2cTransaction.targetAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id));
        if (I2C_transfer(i2c, &i2cTransaction))
        {
            DISPLAY(snprintf(output, 64, "Found\n\r"));
            found = true;
            break;
        }
        DISPLAY(snprintf(output, 64, "No\n\r"));
    }
    if (!found)
    {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"));
    }
}

// Read temperature from I2C sensor
int16_t readTemp(void)
{
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        temperature = (rxBuffer[0] << 8) | rxBuffer[1];
        temperature *= 0.0078125; // Convert to degrees C
        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000; // Handle negative temperatures
        }
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor\n\r"));
    }
    return temperature;
}

// Timer callback function to set the TimerFlag
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1; // Set by timer interrupt
}

// Initialize and start the timer
void initTimer(void)
{
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 100000; // Set period for 100ms
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL || Timer_start(timer0) == Timer_STATUS_ERROR) {
        while (1); // Enter an infinite loop if timer fails
    }
}

// Control heating element based on temperature
void updateHeater(void)
{
    if (temperature < setpoint) {
        GPIO_write(CONFIG_GPIO_LED_0, 1); // Turn on heater
        heat = 1;
    } else {
        GPIO_write(CONFIG_GPIO_LED_0, 0); // Turn off heater
        heat = 0;
    }
}

// Button press handlers
volatile int button0State = 0;
volatile int button1State = 0;

void gpioButtonFxn0(uint_least8_t index) {
    button0State = 1;
}

void gpioButtonFxn1(uint_least8_t index) {
    button1State = 1;
}

// Check button states and update setpoints
void checkButtons(void) {
    if (button0State) {
        setpoint++;
        button0State = 0;
    }
    if (button1State) {
        setpoint--;
        button1State = 0;
    }
}

// Send current state over UART
void reportState(void)
{
    snprintf(output, sizeof(output), "<%02d,%02d,%d,%04d>\n\r", temperature, setpoint, heat, seconds);
    UART2_write(uart, output, strlen(output), NULL);
}

// Main thread function
void *mainThread(void *arg0)
{
    int lastButtonCheck = 0, lastTempRead = 0, lastUartUpdate = 0;
    initUART();
    initI2C();
    initTimer();
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///// Task Scheduler Explanation /////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // The task scheduler is implemented using a timer (Timer_Handle timer0) that triggers an interrupt every 100 milliseconds,
    // setting the TimerFlag. The main thread continuously checks this flag, and when set, it resets the flag and increments
    // a system clock counter (seconds). Based on the elapsed time, it executes various functions (checkButtons, readTemp,
    // updateHeater, reportState) at different intervals defined by constants (e.g., UPDATE_BUTTON_MS, UPDATE_TEMP_MS,
    // UPDATE_UART_MS).
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    while (1) {
        if (TimerFlag) {
            TimerFlag = 0;
            seconds++; // Increment system clock

            // Task scheduler checks and executes tasks based on time elapsed
            if ((seconds * 100) - lastButtonCheck >= UPDATE_BUTTON_MS) {
                checkButtons();
                lastButtonCheck = seconds * 100;
            }
            if ((seconds * 100) - lastTempRead >= UPDATE_TEMP_MS) {
                temperature = readTemp();
                updateHeater();
                lastTempRead = seconds * 100;
            }
            if ((seconds * 100) - lastUartUpdate >= UPDATE_UART_MS) {
                reportState();
                lastUartUpdate = seconds * 100;
            }
        }
    }
    return NULL;
}
