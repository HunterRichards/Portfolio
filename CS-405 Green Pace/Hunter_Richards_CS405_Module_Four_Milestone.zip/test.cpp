// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

TEST_F(CollectionTest, AddSingleValueToEmptyVector)
{
    // Verify that a new collection is initially empty and has a size of 0.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // Add a single entry to the collection and check if the collection is no longer empty
    // and its size has increased to 1.
    add_entries(1);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, AddFiveValuesToVector)
{
    // Add five entries to the collection and verify if the size of the collection
    // has increased to 5.
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, MaxSizeGreaterOrEqualToSize)
{
    // Testing the collection to ensure its max_size is always greater than or equal to its current size.
    // This test iterates over different entry counts (0, 1, 5, 10), adding entries to the collection for each count.
    // For a count of 0, no entries are added, testing the condition when the collection is empty.
    // The test asserts that the max_size of the collection is always greater or equal to its current size,
    // irrespective of the number of entries in it. This includes scenarios where the collection is empty or has entries.
    std::vector<int> entryCounts = { 0, 1, 5, 10 };
    for (int count : entryCounts) {
        if (count > 0) {
            add_entries(count);
        }
        ASSERT_GE(collection->max_size(), collection->size());
        collection->clear(); // Reset the collection for the next test count
    }
}

TEST_F(CollectionTest, CapacityGreaterOrEqualToSize)
{
    // Testing to ensure that the capacity of the collection is always greater than or equal to its size.
    // This test covers several scenarios by iterating over entry counts of 0, 1, 5, and 10.
    // For each count, it adds that number of entries to the collection, except for 0, which tests the empty case.
    // The test then verifies that the collection's capacity is always at least as large as its size,
    // catering to both cases where the collection may be empty or contain a number of elements.
    std::vector<int> entryCounts = { 0, 1, 5, 10 };
    for (int count : entryCounts) {
        if (count > 0) {
            add_entries(count);
        }
        ASSERT_GE(collection->capacity(), collection->size());
        collection->clear(); // Reset the collection for the next test count
    }
}


TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    // Resize the collection to a larger size (10) and verify that
    // the size of the collection has been updated to match this new size.
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);
}


TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    // Add ten entries to the collection, then resize it to a smaller size (5).
    // Verify that the size of the collection has been reduced to 5.
    add_entries(10);
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
    // Add ten entries to the collection and then resize it to zero.
    // Verify that the collection is now empty.
    add_entries(10);
    collection->resize(0);
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ClearErasesCollection)
{
    // Add ten entries to the collection and then clear it.
    // Verify that the collection is empty after clearing.
    add_entries(10);
    collection->clear();
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, EraseAllErasesCollection)
{
    // Add ten entries to the collection and then erase all elements from it.
    // Verify that the collection is empty after the erase operation.
    add_entries(10);
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    // Record the initial capacity of the collection, then increase the capacity.
    // Verify that the new capacity is greater than or equal to the initial capacity
    // and that the size of the collection remains unchanged.
    size_t initialCapacity = collection->capacity();
    collection->reserve(50);
    ASSERT_GE(collection->capacity(), initialCapacity);
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, OutOfRangeExceptionOnInvalidAtAccess)
{
    // Verify that accessing an element at an invalid index (1) in an empty collection
    // throws an out_of_range exception.
    EXPECT_THROW(collection->at(1), std::out_of_range);
}

// Positive test
TEST_F(CollectionTest, FrontAndBackCorrectAfterAdditions)
{
    // Add three entries to the collection and verify that the values at the front
    // and back of the collection are within the expected range (0 to 99).
    add_entries(3);
    int front = collection->front();
    int back = collection->back();

    ASSERT_TRUE(front >= 0 && front < 100);
    ASSERT_TRUE(back >= 0 && back < 100);
}

// Negative test
TEST_F(CollectionTest, AccessElementInEmptyCollectionThrowsException)
{
    // Verify that the collection is initially empty.
    ASSERT_TRUE(collection->empty());

    // Attempt to access the first element in the empty collection.
    // This should throw a std::out_of_range exception since there are no elements in the collection.
    EXPECT_THROW(collection->at(0), std::out_of_range);
}