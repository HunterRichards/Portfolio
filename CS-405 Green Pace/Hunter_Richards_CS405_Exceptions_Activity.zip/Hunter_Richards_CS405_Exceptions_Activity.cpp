// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// Custom exception class
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        // This method overrides std::exception's what() to provide a custom message
        return "Custom exception occurred";
    }
};

bool do_even_more_custom_application_logic() {
    // Throwing a standard exception
    throw std::runtime_error("Standard exception in do_even_more_custom_application_logic");
    // Intention: To simulate an error condition using a standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic() {
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // Catching standard exceptions and displaying the error message
        std::cout << "Exception caught: " << e.what() << std::endl;
        // Intention: To handle exceptions from do_even_more_custom_application_logic
    }

    // Throwing a custom exception
    throw CustomException();
    // Intention: To demonstrate throwing and catching a custom exception

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
    if (den == 0) {
        // Throwing an exception for divide by zero
        throw std::invalid_argument("Divide by zero error");
        // Intention: To handle divide by zero errors appropriately
    }
    return (num / den);
}


void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e) {
        // Catching exceptions specifically from the divide function
        std::cout << "Exception caught in do_division: " << e.what() << std::endl;
        // Intention: To handle division-specific errors, especially divide by zero
    }
}

int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        // Catching custom exceptions first
        std::cout << "Custom Exception caught: " << e.what() << std::endl;
        // Intention: To demonstrate catching a custom exception
    }
    catch (const std::exception& e) {
        // Catching standard exceptions
        std::cout << "Standard Exception caught: " << e.what() << std::endl;
        // Intention: To handle all other standard exceptions
    }
    catch (...) {
        // Catch-all for any other uncaught exceptions
        std::cout << "Unknown exception caught" << std::endl;
        // Intention: To catch any other exceptions not caught by the above handlers
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu