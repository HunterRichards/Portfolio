// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

/// <summary>
/// Template function that performs addition in a controlled manner to avoid overflow.
/// It iteratively adds 'increment' to 'start', 'steps' times. During each addition, 
/// it checks for potential overflow. For integral types, it checks if adding 'increment'
/// would exceed the maximum value for the type. For floating-point types, it checks if the
/// result becomes infinity, indicating overflow. If an overflow is detected, the function
/// returns the current result and a flag indicating the overflow.
/// </summary>
/// <typeparam name="T">A numeric type supporting addition and limits checking.</typeparam>
/// <param name="start"> - The starting value for addition.</param>
/// <param name="increment"> - The value to be added in each step.</param>
/// <param name="steps"> - The number of iterations for addition.</param>
/// <returns>A pair consisting of the final result and a boolean flag indicating whether overflow occurred (false) or not (true).</returns>
template <typename T>
std::pair<T, bool> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;
    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for overflow. If the current result plus increment exceeds the type's max limit, overflow is detected
        if constexpr (std::is_integral<T>::value) {
            if ((increment > 0 && result > std::numeric_limits<T>::max() - increment) ||
                (increment < 0 && result < std::numeric_limits<T>::min() - increment)) {
                return { result, false }; // Overflow detected
            }
        }
        result += increment;
        // For floating-point types, check if the result is infinity (indicates overflow)
        if constexpr (std::is_floating_point<T>::value) {
            if (result == std::numeric_limits<T>::infinity() || result == -std::numeric_limits<T>::infinity()) {
                return { result, false }; // Floating-point overflow detected
            }
        }
    }
    return { result, true };
}

/// <summary>
/// Template function that performs subtraction in a controlled manner to avoid underflow.
/// It iteratively subtracts 'decrement' from 'start', 'steps' times. During each subtraction,
/// it checks for potential underflow. For integral types, it checks if subtracting 'decrement'
/// would go below the minimum value for the type. For floating-point types, it checks if the
/// result becomes negative infinity, indicating underflow. If an underflow is detected, the function
/// returns the current result and a flag indicating the underflow.
/// </summary>
/// <typeparam name="T">A numeric type supporting subtraction and limits checking.</typeparam>
/// <param name="start"> - The starting value for subtraction.</param>
/// <param name="decrement"> - The value to be subtracted in each step.</param>
/// <param name="steps"> - The number of iterations for subtraction.</param>
/// <returns>A pair consisting of the final result and a boolean flag indicating whether underflow occurred (false) or not (true).</returns>
template <typename T>
std::pair<T, bool> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;
    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for underflow. If the current result minus decrement goes below the type's min limit, underflow is detected
        if constexpr (std::is_integral<T>::value) {
            if ((decrement > 0 && result < std::numeric_limits<T>::min() + decrement) ||
                (decrement < 0 && result > std::numeric_limits<T>::max() + decrement)) {
                return { result, false }; // Underflow detected
            }
        }
        result -= decrement;
        // For floating-point types, check if the result is negative infinity (indicates underflow)
        if constexpr (std::is_floating_point<T>::value) {
            if (result == -std::numeric_limits<T>::infinity()) {
                return { result, false }; // Floating-point underflow detected
            }
        }
    }
    return { result, true };
}

//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Testing the scenario without overflow
    auto result_pair = add_numbers<T>(start, increment, steps);
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    if (!result_pair.second) {
        std::cout << "Overflow detected" << std::endl;
    }
    else {
        std::cout << +result_pair.first << std::endl;
    }

    // Testing the scenario with overflow
    result_pair = add_numbers<T>(start, increment, steps + 10);
    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 10) << ") = ";
    if (!result_pair.second) {
        std::cout << "Overflow detected" << std::endl;
    }
    else {
        std::cout << +result_pair.first << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Testing the scenario without underflow
    auto result_pair = subtract_numbers<T>(start, decrement, steps);
    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    if (!result_pair.second) {
        std::cout << "Underflow detected" << std::endl;
    }
    else {
        std::cout << +result_pair.first << std::endl;
    }

    // Testing the scenario with underflow
    result_pair = subtract_numbers<T>(start, decrement, steps + 10);
    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 10) << ") = ";
    if (!result_pair.second) {
        std::cout << "Underflow detected" << std::endl;
    }
    else {
        std::cout << +result_pair.first << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu