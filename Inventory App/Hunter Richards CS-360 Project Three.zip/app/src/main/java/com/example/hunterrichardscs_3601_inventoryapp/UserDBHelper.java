package com.example.hunterrichardscs_3601_inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * SQLiteOpenHelper class for managing the user database.
 * This class provides methods to perform operations like creating, reading,
 * and updating user records in the database for authentication purposes.
 */
public class UserDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "UserDatabase";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    private static final String CREATE_TABLE_USERS = "CREATE TABLE "
            + TABLE_USERS + "(" + COLUMN_USERNAME + " TEXT PRIMARY KEY,"
            + COLUMN_PASSWORD + " TEXT" + ")";

    /**
     * Constructor for UserDBHelper.
     * @param context Context of the application
     */
    public UserDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_USERS);
        } catch (SQLException e) {
            Log.e("UserDBHelper", "Error creating database table: " + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Implement schema changes and database upgrade logic here
    }

    /**
     * Adds a new user to the database.
     * @param username Username for the new user
     * @param password Password for the new user
     */
    public void addUser(String username, String password) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_USERNAME, username);
            values.put(COLUMN_PASSWORD, password);
            db.insert(TABLE_USERS, null, values);
        } catch (SQLException e) {
            Log.e("UserDBHelper", "Error adding user: " + e.getMessage());
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    /**
     * Checks if a user exists in the database with the provided username and password.
     * @param username Username of the user
     * @param password Password of the user
     * @return true if the user exists, false otherwise
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.query(TABLE_USERS, new String[] { COLUMN_USERNAME, COLUMN_PASSWORD },
                    COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                    new String[] { username, password }, null, null, null);
            return cursor.getCount() > 0;
        } catch (SQLException e) {
            Log.e("UserDBHelper", "Error checking user: " + e.getMessage());
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
    }

    /**
     * Checks if a username already exists in the database.
     * @param username Username to check in the database
     * @return true if the username exists, false otherwise
     */
    public boolean doesUsernameExist(String username) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String[] columns = { COLUMN_USERNAME };
            String selection = COLUMN_USERNAME + " = ?";
            String[] selectionArgs = { username };
            cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            return cursor.getCount() > 0;
        } catch (SQLException e) {
            Log.e("UserDBHelper", "Error checking if username exists: " + e.getMessage());
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
    }
}
