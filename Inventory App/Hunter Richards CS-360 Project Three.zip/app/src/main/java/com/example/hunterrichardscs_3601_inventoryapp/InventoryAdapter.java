package com.example.hunterrichardscs_3601_inventoryapp;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Adapter class for inventory items RecyclerView.
 * This class binds inventory data from a Cursor to views that are displayed within a RecyclerView.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private Context context;
    private Cursor cursor;

    /**
     * Constructor for InventoryAdapter.
     * @param context Context of the application
     * @param cursor Cursor holding inventory data
     */
    public InventoryAdapter(Context context, Cursor cursor) {
        this.context = context;
        this.cursor = cursor;
    }

    /**
     * Updates the cursor with new data and closes the old cursor.
     * Ensures that the cursor is not null before attempting to access it.
     * @param newCursor New cursor with updated data
     */
    public void setCursor(Cursor newCursor) {
        if (cursor != null) cursor.close();
        cursor = newCursor;
    }

    @Override
    public InventoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.inventory_recycler, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(InventoryViewHolder holder, int position) {
        if (cursor == null || !cursor.moveToPosition(position)) {
            // Handling potential null cursor or invalid cursor position
            return;
        }

        // Retrieve column indexes for item name and quantity
        int itemNameIndex = cursor.getColumnIndex(InventoryDBHelper.COLUMN_ITEM_NAME);
        int quantityIndex = cursor.getColumnIndex(InventoryDBHelper.COLUMN_QUANTITY);

        if (itemNameIndex == -1 || quantityIndex == -1) {
            // Column index is invalid.
            return;
        }

        String itemName = cursor.getString(itemNameIndex);
        int quantity = cursor.getInt(quantityIndex);

        holder.itemNameTextView.setText(itemName);
        holder.itemQuantityEditText.setText(String.valueOf(quantity));

        // Set a click listener to handle deletion of an item
        holder.deleteButton.setOnClickListener(view -> {
            try {
                ((InventoryScreen) context).deleteItem(itemName);
            } catch (Exception e) {
                Toast.makeText(context, "Error deleting item", Toast.LENGTH_SHORT).show();
            }
        });

        // Listener to handle changes in quantity of an item
        holder.itemQuantityEditText.setOnFocusChangeListener((view, hasFocus) -> {
            if (!hasFocus) {
                try {
                    long newQuantity = Long.parseLong(holder.itemQuantityEditText.getText().toString());
                    ((InventoryScreen) context).updateItemQuantity(itemName, newQuantity);
                } catch (NumberFormatException e) {
                    Toast.makeText(context, "Invalid quantity format", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(context, "Error updating quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        if (cursor != null) {
            return cursor.getCount();
        }
        return 0;
    }

    /**
     * ViewHolder class for RecyclerView items.
     * This class holds references to the views for each data item, which is a simple item layout.
     */
    public class InventoryViewHolder extends RecyclerView.ViewHolder {

        TextView itemNameTextView;
        EditText itemQuantityEditText;
        Button deleteButton;

        public InventoryViewHolder(View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            itemQuantityEditText = itemView.findViewById(R.id.itemQuantityEditText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}