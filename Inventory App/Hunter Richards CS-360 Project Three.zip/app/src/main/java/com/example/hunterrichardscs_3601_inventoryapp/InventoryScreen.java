package com.example.hunterrichardscs_3601_inventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Activity class representing the inventory screen of the application.
 * This class manages the user interface for adding, updating, and viewing inventory items.
 */
public class InventoryScreen extends AppCompatActivity {

    private InventoryDBHelper dbHelper;
    private EditText itemNameEditText, itemQuantityEditText;
    private Button addItemButton;
    private RecyclerView inventoryRecyclerView;
    private InventoryAdapter adapter;
    private CheckBox notifySMSButton;
    private static final int SMS_PERMISSION_CODE = 101;
    private boolean isSMSPermissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_database);

        // Initialize the database helper
        dbHelper = new InventoryDBHelper(this);

        // Initialize UI components
        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);
        addItemButton = findViewById(R.id.addItemButton);
        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemQuantityEditText = findViewById(R.id.itemQuantityEditText);
        notifySMSButton = findViewById(R.id.notifySMSButton);

        // Set up RecyclerView
        inventoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(this, dbHelper.getAllItems());
        inventoryRecyclerView.setAdapter(adapter);

        // Add item button listener
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
            }
        });

        // Add listener for notifySMSButton
        notifySMSButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                requestSMSPermission();
            } else {
                isSMSPermissionGranted = false;
            }
        });
    }

    /**
     * Requests SMS permission from the user.
     */
    private void requestSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            isSMSPermissionGranted = true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            // Check if SMS permission is granted
            isSMSPermissionGranted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            notifySMSButton.setChecked(isSMSPermissionGranted);
        }
    }

    /**
     * Adds a new item to the inventory.
     * Validates the input fields before adding the item to the database.
     */
    private void addItem() {
        String itemName = itemNameEditText.getText().toString();
        String quantityStr = itemQuantityEditText.getText().toString();
        if (!itemName.isEmpty() && !quantityStr.isEmpty()) {
            try {
                long quantity = Long.parseLong(quantityStr);
                dbHelper.addItem(itemName, quantity);
                refreshInventoryList();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid quantity format", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Updates the quantity of an existing item in the inventory.
     * @param itemName Name of the item to update
     * @param newQuantity New quantity value for the item
     */
    public void updateItemQuantity(String itemName, long newQuantity) {
        try {
            dbHelper.updateItemQuantity(itemName, newQuantity);
            if (newQuantity == 0 && isSMSPermissionGranted) {
                sendSMSNotification(itemName);
            }
            refreshInventoryList();
        } catch (Exception e) {
            Toast.makeText(this, "Error updating item", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Sends an SMS notification when an item quantity reaches zero.
     * @param itemName Name of the item that has reached zero quantity
     */
    private void sendSMSNotification(String itemName) {
        String phoneNumber = "1234567890"; // Replace with actual phone number
        String message = "Alert: The quantity of " + itemName + " has reached zero.";

        if (!isSMSPermissionGranted) {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(getApplicationContext(), "SMS Sent Successfully", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "SMS Failed to Send", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Deletes an item from the inventory.
     * @param itemName Name of the item to be deleted
     */
    public void deleteItem(String itemName) {
        try {
            dbHelper.deleteItem(itemName);
            refreshInventoryList();
        } catch (Exception e) {
            Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Refreshes the inventory list displayed on the RecyclerView.
     */
    private void refreshInventoryList() {
        new Handler(Looper.getMainLooper()).post(() -> {
            adapter.setCursor(dbHelper.getAllItems());
            adapter.notifyDataSetChanged();
        });
    }
}