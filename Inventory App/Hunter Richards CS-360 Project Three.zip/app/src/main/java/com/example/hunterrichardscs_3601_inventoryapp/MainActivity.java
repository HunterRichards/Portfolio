package com.example.hunterrichardscs_3601_inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;

/**
 * Main Activity class serving as the entry point of the application.
 * This class redirects the user to the LoginScreen upon app startup.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            // Start LoginScreen activity
            Intent intent = new Intent(this, LoginScreen.class);
            startActivity(intent);
            finish(); // Close MainActivity
        } catch (Exception e) {
            // Log the exception (could use Android's Log class)
            // Handle any unexpected exceptions here, like issues with intent creation
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Additional cleanup if needed when the activity is destroyed
        // Currently, there's no database or resource to close in this activity
    }
}