package com.example.hunterrichardscs_3601_inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * SQLiteOpenHelper class for managing the inventory database.
 * This class provides methods to perform operations like creating, reading,
 * updating, and deleting inventory items in the database.
 */
public class InventoryDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryDatabase";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_INVENTORY = "inventory";
    public static final String COLUMN_ITEM_NAME = "itemName";
    public static final String COLUMN_QUANTITY = "quantity";

    private static final String CREATE_TABLE_INVENTORY = "CREATE TABLE "
            + TABLE_INVENTORY + "(" + COLUMN_ITEM_NAME + " TEXT PRIMARY KEY,"
            + COLUMN_QUANTITY + " LONG" + ")";

    /**
     * Constructor for InventoryDBHelper.
     * @param context Context of the application
     */
    public InventoryDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_INVENTORY);
        } catch (SQLException e) {
            Log.e("InventoryDBHelper", "Error creating database table: " + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Implement schema changes and database upgrade logic here
    }

    /**
     * Adds a new item to the inventory.
     * @param itemName Name of the new item
     * @param quantity Quantity of the new item
     */
    public void addItem(String itemName, long quantity) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_ITEM_NAME, itemName);
            values.put(COLUMN_QUANTITY, quantity);
            db.insert(TABLE_INVENTORY, null, values);
        } catch (SQLException e) {
            Log.e("InventoryDBHelper", "Error adding item: " + e.getMessage());
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    /**
     * Deletes an item from the inventory.
     * @param itemName Name of the item to delete
     */
    public void deleteItem(String itemName) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            db.delete(TABLE_INVENTORY, COLUMN_ITEM_NAME + " = ?", new String[] { itemName });
        } catch (SQLException e) {
            Log.e("InventoryDBHelper", "Error deleting item: " + e.getMessage());
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    /**
     * Updates the quantity of an existing item in the inventory.
     * @param itemName Name of the item to update
     * @param newQuantity New quantity value for the item
     */
    public void updateItemQuantity(String itemName, long newQuantity) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_QUANTITY, newQuantity);
            db.update(TABLE_INVENTORY, values, COLUMN_ITEM_NAME + " = ?", new String[] { itemName });
        } catch (SQLException e) {
            Log.e("InventoryDBHelper", "Error updating item quantity: " + e.getMessage());
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    /**
     * Retrieves all items from the inventory.
     * @return Cursor pointing to the set of all inventory items
     */
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_INVENTORY, new String[] { COLUMN_ITEM_NAME, COLUMN_QUANTITY },
                null, null, null, null, null);
    }
}